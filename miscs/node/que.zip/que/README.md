Add bytecode in some file (like main.txt sample)
Run with the file path as argument

```bash
npm run que -- "./main.txt"
```
